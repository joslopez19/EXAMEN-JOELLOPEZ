package calculeoperadores;

import java.util.Scanner;

public class CalcularAtravezOperadores {

	public static void main(String[] args) {
		// realice un programa que calcule atravez de operadores (caracteres) +,-,*,/
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese el primer numero");
		double num1 = sc.nextDouble();
		System.out.println("Ingrese el segundo numero");
		double num2 = sc.nextDouble();
		
		System.out.println("Ingrese los operadores (+,-,*,/)");
		
		char operador = sc.next().charAt(0);
		
		double result;
		
		switch (operador) {
		
		case  '+': result = num1+num2;
		
		break; case '-': result =num1-num2;
		
		break; case '*': result =num1*num2;
		break; case '/': result =num1/num2;
		
		break; default:
			
			System.out.println("Operador invalido");
			return;
		}
		
		System.out.println(num1 +""+operador+""+num2+" ="+result);
		
		
		
	}

}
