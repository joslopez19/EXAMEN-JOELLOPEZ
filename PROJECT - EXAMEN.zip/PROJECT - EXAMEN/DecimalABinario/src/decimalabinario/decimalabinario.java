package decimalabinario;

import java.util.Scanner;

public class decimalabinario {
	
	public static void main(String[] args) {
	
		Scanner leer = new Scanner(System.in);
		int decimal,modulo,aux;
		String binario ="";
		System.out.println("Ingresa el numero decimal");
		decimal = leer.nextInt();
		aux = decimal;
		while (decimal > 0) {
			modulo = (decimal%2);
			binario = modulo + binario;
			decimal = decimal/2;
			
		}
		
		System.out.println("El numero "+aux+" base es 10 ="+binario+" en base 2");
		
		
	}

}
