package leafrase;
import java.util.Scanner;

public class LeaFrase {

	public static void main(String[] args) {
		// realice un programa que lea una frase e imprima el tamo de esa frase 
		
		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println("Ingrese la frase");
		
		String frase = sc.nextLine();
		
		System.out.println("Length: "+frase.length());
		

	}

}
