package nvectores;

import java.util.Scanner;

public class LeaNVectores {

	public static void main(String[] args) {
		// realice un programa que lea N vectores y ordene de menor a mayor en un arreglo
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese el numero de los elementos");
		int n = sc.nextInt();
		
		int [] arreglo = new int[n];
		System.out.println("Ingrese "+n+"Entero");
		
		for (int i=0; i<n; i++) {
			
			arreglo [i] = sc.nextInt();
			
			
		}
		
	System.out.println("Ordena los arreglos ="+arreglo);

	}

}
