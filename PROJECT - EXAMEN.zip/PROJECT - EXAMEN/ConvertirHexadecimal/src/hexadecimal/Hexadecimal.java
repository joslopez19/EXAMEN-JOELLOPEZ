package hexadecimal;

import java.util.Scanner;

public class Hexadecimal {

	public static void main(String[] args) {
		// 1. covertir a Hexadecimal el siguiente numero  1011111001
		
		
		Scanner datoScanner = new Scanner(System.in);

        String binario = "1011111001";
        
        int decimal = Integer.parseInt(binario, 2);
        String hexadecimal = 	Integer.toHexString(decimal);
        
        System.out.println("El Hexadecimal es ="+hexadecimal);
        
        
	}

}
