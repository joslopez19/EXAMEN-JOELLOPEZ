package leacadenas;

import java.util.Scanner;


public class LeaCadenas {

	public static void main(String[] args) {
		// realice un programa que lea una	 cadena e invierta y digas cuantos datos tiene
		
		Scanner sc = new Scanner(System.in);
		//declaramos variable
		String cadena;
		
		
		System.out.println("Ingrese la cadena");
		
		cadena = sc.nextLine();
		
		String revertir = new StringBuilder(cadena).reverse().toString();
		
		System.out.println("Ingrese la cadena = "+cadena);
		System.out.println("length: " .length());
		
		
		
		
	}

}
